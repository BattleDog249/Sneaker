package net.shlomo1412.sneaker.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class SneakerClient implements ClientModInitializer {

    private static boolean autoSneakEnabled = false;
    private static class_304 toggleKeyBinding;

    @Override
    public void onInitializeClient() {
        // Register the keybind for toggling auto-sneak
        toggleKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.sneaker.toggle",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_V,
                "category.sneaker"
        ));

        // Register client tick event to handle keybind press
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 != null && toggleKeyBinding.method_1436()) {
                autoSneakEnabled = !autoSneakEnabled;
                
                // Display formatted action bar message
                class_2561 message = class_2561.method_43473()
                        .method_10852(class_2561.method_43470("✦ ").method_27692(class_124.field_1065))
                        .method_10852(class_2561.method_43470("Auto-Sneak").method_27695(class_124.field_1054, class_124.field_1067))
                        .method_10852(class_2561.method_43470(": ").method_27692(class_124.field_1080))
                        .method_10852(autoSneakEnabled 
                                ? class_2561.method_43470("ON").method_27695(class_124.field_1060, class_124.field_1067)
                                : class_2561.method_43470("OFF").method_27695(class_124.field_1061, class_124.field_1067))
                        .method_10852(class_2561.method_43470(" ✦").method_27692(class_124.field_1065));
                
                client.field_1724.method_7353(message, true);
            }
        });
    }

    public static boolean isAutoSneakEnabled() {
        return autoSneakEnabled;
    }
}
