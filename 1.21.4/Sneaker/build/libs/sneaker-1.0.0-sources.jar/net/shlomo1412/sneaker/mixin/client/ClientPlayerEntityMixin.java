package net.shlomo1412.sneaker.mixin.client;

import net.minecraft.class_2338;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_746;
import net.shlomo1412.sneaker.client.SneakerClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_746.class)
public abstract class ClientPlayerEntityMixin {

    @Unique
    private boolean sneaker$wasAutoSneaking = false;

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        class_746 player = (class_746) (Object) this;
        class_310 client = class_310.method_1551();
        
        if (client.field_1690 == null) {
            return;
        }

        // If auto-sneak is disabled, reset state and return
        if (!SneakerClient.isAutoSneakEnabled()) {
            if (sneaker$wasAutoSneaking) {
                class_304.method_1416(client.field_1690.field_1832.method_1429(), false);
                sneaker$wasAutoSneaking = false;
            }
            return;
        }

        // Check if player is on ground
        if (!player.method_24828()) {
            if (sneaker$wasAutoSneaking) {
                class_304.method_1416(client.field_1690.field_1832.method_1429(), false);
                sneaker$wasAutoSneaking = false;
            }
            return;
        }

        // Get player center position
        double playerX = player.method_23317();
        double playerZ = player.method_23321();
        
        // The Y level of the block the player is standing on
        int groundY = (int) Math.floor(player.method_23318()) - 1;
        
        // Player hitbox is 0.6 wide, so 0.3 from center to edge
        // Use 0.3001 for pixel-perfect timing at the very edge
        double halfWidth = 0.3001;
        
        // Calculate the 4 corners of the player's hitbox
        double[][] cornerPoints = {
            {playerX - halfWidth, playerZ - halfWidth},  // Corner 1
            {playerX + halfWidth, playerZ - halfWidth},  // Corner 2
            {playerX - halfWidth, playerZ + halfWidth},  // Corner 3
            {playerX + halfWidth, playerZ + halfWidth}   // Corner 4
        };
        
        boolean shouldSneak = false;
        
        for (double[] corner : cornerPoints) {
            class_2338 cornerBlockPos = new class_2338(
                (int) Math.floor(corner[0]), 
                groundY, 
                (int) Math.floor(corner[1])
            );
            
            // Check if this corner is over air at the SAME level as the block we're standing on
            // This is the key change: we only care if the block at foot level is missing
            // (meaning we'd walk off our current block), regardless of what's below
            if (!player.method_37908().method_8320(cornerBlockPos).method_51367()) {
                shouldSneak = true;
                break;
            }
        }
        
        // Apply or release auto-sneak
        if (shouldSneak) {
            class_304.method_1416(client.field_1690.field_1832.method_1429(), true);
            sneaker$wasAutoSneaking = true;
        } else {
            // Safe to release - no edges detected
            if (sneaker$wasAutoSneaking) {
                class_304.method_1416(client.field_1690.field_1832.method_1429(), false);
                sneaker$wasAutoSneaking = false;
            }
        }
    }
}
